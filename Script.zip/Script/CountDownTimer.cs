
using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Collections.Generic;

public class CountDownTimer : MonoBehaviour
{

	//��������
	private float totalTime;
	[SerializeField]
	private int minute;
	[SerializeField]
	private float seconds;

	//GameObject
	private float oldSeconds;
	private Text timerText;
	public GameObject timeup;
	public GameObject rc;
	public GameObject canvas;
	public GameObject player;
	public GameObject enemy;
	public GameObject enemyB;
	public GameObject sw;
	public GameObject ground;
	public GameObject ebf;
	public GameObject enemy2;
	public GameObject enemyB2;
	public GameObject ebf2;
	public GameObject gun1;
	public GameObject gun2;
	public GameObject sight2;
	public GameObject sight3;
	public GameObject sight4;
	public GameObject gc;
	public GameObject r2;

	[SerializeField] AudioSource audioSource;
	[SerializeField] AudioClip audioClip;
	private bool isAudioEnd;

	//�X�R�A
	[SerializeField] private GameObject sm;
	[SerializeField] private GameObject rt;

	private float step_time;
	RaycastHit hit;

	//�������Ԃɂ��\���E��\������
	void Start()
	{
		totalTime = minute * 60 + seconds;
		oldSeconds = 0f;
		timerText = GetComponentInChildren<Text>();
		if (ebf.activeSelf == false)
		{
			ebf.SetActive(true);
		}
		if (ebf2.activeSelf == false)
		{
			ebf2.SetActive(true);
		}
		audioSource = GetComponent<AudioSource>();
		isAudioEnd = false;
		audioSource.clip = audioClip;
	}

	void Update()
	{
		if (totalTime <= 50f)
		{
			enemy2.SetActive(true);
			r2.SetActive(true);
		}

		if (totalTime <= 48f)
		{
			r2.SetActive(false);
		}

		if (totalTime <= 30f)
		{
			gun1.SetActive(false);
			gun2.SetActive(true);
			sight2.SetActive(true);
			sight3.SetActive(true);
			sight4.SetActive(true);
			gc.SetActive(true);
		}

		if (totalTime <= 27f)
		{
			gc.SetActive(false);
		}

		if (totalTime <= 0f)
		{
			timeup.SetActive(true);
			enemyB.SetActive(false);
			enemyB2.SetActive(false);
			audioSource.Play();
			isAudioEnd = true;
			//SceneManager.LoadScene("ResultClearScene");

			// Result��ʏ���
			step_time += Time.deltaTime;
			if (step_time >= 1.5f)
			{
				rc.SetActive(true);
				rt.GetComponent<Text>().text = "SCORE�F"+(sm.GetComponent<Score>().score).ToString();

				if (rc.activeSelf)
				{
					rc.SetActive(true);
				}
                else if (rc.activeSelf==false)
				{ 
				
				}

				canvas.SetActive(false);
				player.SetActive(false);
				sw.SetActive(false);
				ground.SetActive(false);
				//SceneManager.LoadScene("ResultClearScene");

				GameObject[] enemyBullets = GameObject.FindGameObjectsWithTag("EnemyBullet");
				foreach (GameObject enemyBullet in enemyBullets)
				{
					Destroy(enemyBullet);
				}

				GameObject[] enemyBullets2 = GameObject.FindGameObjectsWithTag("EnemyBullet2");
				foreach (GameObject enemyBullet2 in enemyBullets2)
				{
					Destroy(enemyBullet2);
				}

				GameObject[] enemys = GameObject.FindGameObjectsWithTag("Enemy");
				foreach (GameObject enemy in enemys)
				{
					Destroy(enemy);
				}

				GameObject[] enemys2 = GameObject.FindGameObjectsWithTag("Enemy2");
				foreach (GameObject enemy2 in enemys2)
				{
					//Destroy(enemy2);
				}
			}

			return;
		}

		//�������Ԍo�߂œG�̍U���폜
		if (totalTime <= 0.01f)
		{
			GameObject[] enemyBullets = GameObject.FindGameObjectsWithTag("EnemyBullet");
			foreach (GameObject enemyBullet in enemyBullets)
			{
				Destroy(enemyBullet);
			}

			GameObject[] enemyBullets2 = GameObject.FindGameObjectsWithTag("EnemyBullet2");
			foreach (GameObject enemyBullet2 in enemyBullets2)
			{
				Destroy(enemyBullet2);
			}

			GameObject[] enemys = GameObject.FindGameObjectsWithTag("Enemy");
			foreach (GameObject enemy in enemys)
			{
				Destroy(enemy);
			}

			GameObject[] enemys2 = GameObject.FindGameObjectsWithTag("Enemy2");
			foreach (GameObject enemy2 in enemys2)
			{
				//Destroy(enemy2);
			}
		}

		//�g�[�^���������Ԍv���G
		totalTime = minute * 60 + seconds;
		totalTime -= Time.deltaTime;

		//�Đݒ�
		minute = (int)totalTime / 60;
		seconds = totalTime - minute * 60;

		//�^�C�}�[�\���pUI�e�L�X�g�Ɏ��ԕ\��
		if ((int)seconds != (int)oldSeconds)
		{
			timerText.text = minute.ToString("00") + ":" + ((int)seconds).ToString("00");
		}
		oldSeconds = seconds;
	}
}