﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorState : MonoBehaviour
{

    void Start()
    {
        //カーソル非表示
        Cursor.visible = false;
        //カーソル中央固定
        Cursor.lockState = CursorLockMode.Locked;
    }

    void Update()
    {
        
    }
}
