using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletHP2 : MonoBehaviour
{
    //HP
    [SerializeField] int enemyBulletHP2;


    public int score;  
    private Score sm;

    //��������
    private float totalTime;
    [SerializeField]
    private int minute;
    [SerializeField]
    private float seconds = 1.0f;
    private float oldSeconds;

    //���ԏ���
    void Start()
    {
        sm = GameObject.Find("ScoreManager").GetComponent<Score>();
        totalTime = minute * 60 + seconds;
        oldSeconds = 0f;
    }

    //�G��HP��0�ȉ��ɂ�����j��
    void Update()
    {
        if (totalTime <= 0f)
        {
            enemyBulletHP2 -= (0);
            if (enemyBulletHP2 <= 0)
            {
                Destroy(gameObject);
            }
        }
    }

    //��_�������@�|�C���g�t�^
    public void ReceveDamage(int damageScore)
    {
        enemyBulletHP2 -= damageScore;
        Debug.Log("enemyBulletHP2:" + enemyBulletHP2);
        if (enemyBulletHP2 <= 0)
        {
            sm.AddScore(200);�@
            Destroy(gameObject);
        }
    }
}