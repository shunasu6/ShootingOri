using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHP2 : MonoBehaviour
{
    //HP
    [SerializeField] int enemyHP;

    public int score;
    private Score sm;

    void Start()
    {
        sm = GameObject.Find("ScoreManager").GetComponent<Score>();
    }

    void Update()
    {

    }

    //��_������
    public void ReceveDamage(int damageScore)
    {
        enemyHP -= damageScore;
        Debug.Log("enemyHP:" + enemyHP);

        if (enemyHP <= 0)
        {
            GameObject[] enemyBullets = GameObject.FindGameObjectsWithTag("EnemyBullet2");

            foreach (GameObject enemyBullet in enemyBullets)
            {
                Destroy(enemyBullet);
            }

            sm.AddScore(1000);
            Destroy(gameObject); 
        }
    }
}