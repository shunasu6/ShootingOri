using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooting2 : MonoBehaviour
{
    [SerializeField] GameObject enemyBulletPrefab;
    [SerializeField] float shotInterval;
    float timeCount;


    void Start()
    {

    }

    void Update()
    {
        //���Ԍv��
        timeCount += Time.deltaTime;
        if (timeCount >= shotInterval)
        {
            timeCount = 0;
            //�e����
            Instantiate(enemyBulletPrefab, transform.position, Quaternion.identity);
        }
    }
}