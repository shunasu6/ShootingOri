﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBulletHP : MonoBehaviour
{
    //HP
    [SerializeField] int enemyBulletHP;


    public int score;
    private Score sm;

    //制限時間
    private float totalTime;
    [SerializeField]
    private int minute;
    [SerializeField]
    private float seconds = 1.0f;
    private float oldSeconds;

    void Start()
    {
        sm = GameObject.Find("ScoreManager").GetComponent<Score>();

        totalTime = minute * 60 + seconds;
        oldSeconds = 0f;
    }

    //制限時間経過したらHPを0にして破壊
    void Update()
    {
        if (totalTime <= 0f)
        {
            enemyBulletHP -= (0);
            if (enemyBulletHP <= 0)
            {
                Destroy(gameObject);
            }
        }
        
    }
        //被ダメ処理　ポイント付与
        public void ReceveDamage(int damageScore)
        {
            enemyBulletHP -= damageScore;
            Debug.Log("enemyBulletHP:" + enemyBulletHP);
            if (enemyBulletHP <= 0)
            {
                sm.AddScore(100);
                Destroy(gameObject);
            }
            
        }
}