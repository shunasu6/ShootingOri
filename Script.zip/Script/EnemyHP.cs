﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHP : MonoBehaviour
{
    //HPゲージ
    [SerializeField] int enemyHP;

    public int score;
    private Score sm;

    void Start()
    {
        sm = GameObject.Find("ScoreManager").GetComponent<Score>();
    }

    void Update()
    {
        
    }

    //被ダメ処理　ポイント付与
    public void ReceveDamage(int damageScore)
    {
        enemyHP -= damageScore;
        Debug.Log("enemyHP:" + enemyHP);

        if (enemyHP <= 0)
        {
            GameObject[] enemyBullets = GameObject.FindGameObjectsWithTag("EnemyBullet");
            foreach (GameObject enemyBullet in enemyBullets)
            {
                Destroy(enemyBullet);
            }
            sm.AddScore(1500);
            Destroy(gameObject);
        }
    }
}