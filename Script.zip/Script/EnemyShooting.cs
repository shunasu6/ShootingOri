﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooting : MonoBehaviour
{
    [SerializeField] GameObject enemyBulletPrefab;
    [SerializeField] float shotInterval;
    float timeCount;

    void Start()
    {
     
    }

    void Update()
    {
        //時間計測
        timeCount += Time.deltaTime;
        if (timeCount >= shotInterval)
        {
            timeCount = 0;
            //弾生成
            Instantiate(enemyBulletPrefab, transform.position, Quaternion.identity);
        }
    }
}