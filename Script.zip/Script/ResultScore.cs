using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ResultScore : MonoBehaviour
{
    private GameObject ScoreMaster;
    private Score Sd;
    private Text ScoreLabel;
    int ResultScores;

    //�W�v�X�R�A
    void Start()
    {
        ScoreMaster = GameObject.Find("ScoreLabel");
        Sd = ScoreMaster.GetComponent<Score>();

        ResultScores = Sd.GetScore();
        ScoreLabel.text = "SCORE�F" + ResultScores;
    }
}