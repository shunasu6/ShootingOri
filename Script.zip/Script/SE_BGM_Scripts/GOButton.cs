using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GOButton : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip audioClip;
    private bool isAudioEnd;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        isAudioEnd = false;
        audioSource.clip = audioClip;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Return))
        {
            audioSource.Play();
            isAudioEnd = true;
        }
    }
}