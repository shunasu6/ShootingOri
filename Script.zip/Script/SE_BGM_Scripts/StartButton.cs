using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartButton : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip audioClip;
    private bool isAudioEnd;

    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        isAudioEnd = false;
        audioSource.clip = audioClip;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.Space))
        {
            audioSource.Play();
            isAudioEnd = true;
        }
    }
}