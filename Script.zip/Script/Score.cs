using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Score : MonoBehaviour
{
    public int score = 0;
    private Text scoreLabel;

    void Start()
    {
        scoreLabel = GameObject.Find("ScoreLabel").GetComponent<Text>();
        scoreLabel.text = "SCORE�F" + score;
    }

    private void Update()
    {
        
    }

    // �X�R�A����
    public void AddScore(int amount)
    {
        score += amount;
        scoreLabel.text = "SCORE�F" + score;
    }

    public int GetScore()
    {
        return score;  
    }

}