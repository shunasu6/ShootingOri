﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//UIを扱う為に必要
using UnityEngine.UI;

//ほとんどの内容をネットから引用
public class SightDisplay : MonoBehaviour
{
    //Imageクラス変数を宣言。SerializeFieldでInspector上から定義
    [SerializeField] Image sight;
    [SerializeField] Image sight2;
    [SerializeField] Image sight3;
    [SerializeField] Image sight4;
    //rayの長さ
    float rayLength = 20000;
    //rayが当たったオブジェクトの情報を取得する為の変数
    RaycastHit hit;
    //敵に与えるダメージの値
    int damageScore = 1;
    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        //カメラの原点からレイを飛ばすとプレイヤー自身のタグを取得してしまう為、Z方向にズラす
        Ray ray = new Ray(transform.position + transform.rotation * new Vector3(0, 0, 0.01f), transform.forward);
        //rayの可視化
        Debug.DrawRay(transform.position + transform.rotation * new Vector3(0, 0, 0.01f), transform.forward * rayLength, Color.yellow);
        //ray上にコライダーが存在する場合、RayCastHit型変数に情報を格納する。out修飾子を付けて、戻り値を取得せずに関数内で変数の値を操作する
        if (Physics.Raycast(ray, out hit, rayLength))
        {
            //hitに取得した情報の内、タグ名を取得
            string hitTagName = hit.transform.gameObject.tag;
            //タグ名がEnemyもしくはEnemyBulletだった場合
            if (hitTagName == "Enemy" || hitTagName == "EnemyBullet")//追記部分
            {
                //Enemyタグのオブジェクトにrayが当たった時の照準の色
                sight.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight2.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight3.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight4.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                //マウスの左ボタンがクリックされたら
                //if (Input.GetMouseButtonDown(0))
                //スペース押したら
                if (Input.GetKey(KeyCode.Space))
                {
                    //以下、追記部分
                    if (hitTagName == "Enemy")
                    {
                        //Enemyオブジェクトに付いているEnemyHPのReceveDamage関数を呼び出す
                        hit.collider.GetComponent<EnemyHP>().ReceveDamage(damageScore);
                    }
                    else if (hitTagName == "EnemyBullet")
                    {
                        //EnemyBulletオブジェクトに付いているEnemyBulletHPのReceveDamage関数を呼び出す
                        hit.collider.GetComponent<EnemyBulletHP>().ReceveDamage(damageScore);
                    }
                    //以上、追記部分

                    
                }
            }


            if (hitTagName == "Enemy2" || hitTagName == "EnemyBullet2")//追記部分
            {
                //Enemyタグのオブジェクトにrayが当たった時の照準の色
                sight.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight2.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight3.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                sight4.color = new Color(1.0f, 0.0f, 0.0f, 1.0f);
                //マウスの左ボタンがクリックされたら
                //if (Input.GetMouseButtonDown(0))
                //スペース押したら
                if (Input.GetKey(KeyCode.Space))
                {//Enemy2の処理
                    if (hitTagName == "Enemy2")
                    {
                        //Enemyオブジェクトに付いているEnemyHP2のReceveDamage関数を呼び出す
                        hit.collider.GetComponent<EnemyHP2>().ReceveDamage(damageScore);
                    }
                    else if (hitTagName == "EnemyBullet2")
                    {
                        Debug.Log("EnemyBullet2呼ぶ");
                        //EnemyBulletオブジェクトに付いているEnemyBulletHP2のReceveDamage関数を呼び出す
                        hit.collider.GetComponent<EnemyBulletHP2>().ReceveDamage(damageScore);
                    }
                }
            }

            else
            {
                //Enemyタグ以外のオブジェクトにrayが当たった時の照準の色
                sight.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                sight2.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                sight3.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
                sight4.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);

            }
        }
        else
        {
            //rayがどのオブジェクトにも当たっていない時(空を向いている時)の照準の色
            sight.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
            sight2.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
            sight3.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
            sight4.color = new Color(1.0f, 1.0f, 1.0f, 0.5f);
        }
    }
}