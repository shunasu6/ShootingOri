using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class StartScene : MonoBehaviour
{

	private void Update()
	{
		if (Input.GetKey(KeyCode.Space))
		{
			SceneManager.LoadScene("MainScene");
		}
	}

	public void StartGame()
	{
		SceneManager.LoadScene("MainScene");
	}
}